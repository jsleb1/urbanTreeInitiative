/**
 * @package 	WordPress
 * @subpackage 	EcoNature
 * @version		1.0.0
 * 
 * Script for Widgets in Admin Panel
 * Created by CMSMasters
 * 
 */


jQuery(document).ready(function() { 
	(function ($) { 
		// 
	} )(jQuery);
} );

